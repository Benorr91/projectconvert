
import React from 'react';
import './App.css';
import ExchangeApp from './comps/exchangeApp';


function App() {


  return (
    <>
   <ExchangeApp></ExchangeApp>
    </>
  );
}

export default App;
